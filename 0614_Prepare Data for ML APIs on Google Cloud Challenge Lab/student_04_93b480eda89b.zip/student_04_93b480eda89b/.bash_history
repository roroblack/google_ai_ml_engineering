gcloud storage cp gs://spls/gsp323/task3.flac ./task3.flac
